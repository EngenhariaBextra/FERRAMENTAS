#ifndef DEFINES_H
#define DEFINES_H

const char* ssid     = "BENFICA";
const char* password = "32217538";
//const char* ssid     = "Bextra Net Virtua";
//const char* password = "bexbahia15";

//const char* host = "192.168.1.107";
//const int httpPort = 32000;

IPAddress ip; //COLOQUE UMA FAIXA DE IP DISPONÍVEL DO SEU ROTEADOR. EX: 192.168.1.110 **** ISSO VARIA, NO MEU CASO É: 192.168.0.175
IPAddress gateway; //GATEWAY DE CONEXÃO (ALTERE PARA O GATEWAY DO SEU ROTEADOR)
IPAddress subnet; //MASCARA DE REDE

#define RELE1_ON digitalWrite(LED_BUILTIN,HIGH)
#define RELE1_OFF digitalWrite(LED_BUILTIN,LOW)
#define RELE2_ON digitalWrite(10,HIGH)
#define RELE2_OFF digitalWrite(10,LOW)

typedef struct
{
  char rele1;
  char rele2;   
  char fim='@'; 
} estrutura4;
estrutura4 rele_ESP8266;

typedef struct
{
    double peso;   
    int qualidade; 
    float versao_firmware;
} estrutura2;
estrutura2 comumica_ESP8266;

typedef struct
{
  char tipo;
  char comando;
  char impressora;
  char copias;
  char texto1[22];
  char texto2[22];
  char cliente[22];
  char produto[22];
  char dataa[12];
  char hora[10];
  char peso[20];
  char peso_bruto[20];
  char tara[20];
  char acumulado[20];
  char fim='@';
} estrutura5;

estrutura5 etiqueta_ESP8266;

typedef struct
{
  char tipo;
  char emailTo1[50];
  char emailTo2[50];
  char server[50];
  char user[50];
  char senha[50];
  uint16_t porta;
  char texto1[22];
  char texto2[22];
  char cliente[22];
  char produto[22];
  char dataa[12];
  char hora[10];
  char peso[20];
  char peso_bruto[20];
  char tara[20];
  char acumulado[20];
  char latitude[20];
  char longitude[20];
  char altitude[20];
  char fim='*';

} estrutura6;

estrutura6 email_ESP8266;

struct Settings {    
    uint32_t ip;
    uint32_t gtw;
    uint32_t mask;
} sett;


#endif // DEFINES_H
