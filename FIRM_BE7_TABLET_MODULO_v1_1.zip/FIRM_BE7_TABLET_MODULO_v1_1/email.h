#ifndef EMAIL_H
#define EMAIL_H

#include "Arduino.h"
#include <EMailSender.h>

extern estrutura6 email_ESP8266;
const char* email_login = "engenharia.bextra";
  const char* email_password = "bexbahia15";
  const char* email_from = "BE7_Tablet";
  const char* smtp_server = "smtp.gmail.com";
  uint16_t smtp_port = 465;
EMailSender emailSend(email_login, email_password, email_from, smtp_server, smtp_port);

void envia_email()
{
	

  
  if(email_ESP8266.tipo==0)
  {	  
    emailSend.setEMailLogin(email_login);
    emailSend.setEMailPassword(email_password);
    emailSend.setSMTPServer(smtp_server);
    emailSend.setEMailFrom(email_from);
    emailSend.setSMTPPort(smtp_port);
    
  }
  else
  {    
    emailSend.setEMailLogin(email_ESP8266.user);
    emailSend.setEMailPassword(email_ESP8266.senha);
    emailSend.setSMTPServer(email_ESP8266.server);
    emailSend.setEMailFrom(email_from);
    emailSend.setSMTPPort(email_ESP8266.porta);
  } 

  

	EMailSender::EMailMessage message;
    message.subject = "PESAGEM REALIZADA: ";
    message.subject += email_ESP8266.dataa;
    message.subject += " as ";
    message.subject += email_ESP8266.hora;
    
    message.message = "Email enviado por Pesagem Embarcada Bextra - BE7 Tablet:\n\r";
    message.message += "Pesagem Realizada: \r\n";
    message.message += "Empresa: ";
    message.message += email_ESP8266.texto1;
    message.message += "\r\n";
    message.message += "Placa: ";
    message.message += email_ESP8266.texto2;
    message.message += "\r\n";
    message.message += "Cliente: ";
    message.message += email_ESP8266.cliente;
    message.message += "\r\n";
    message.message += "Produto: ";
    message.message += email_ESP8266.produto;
    message.message += "\r\n";
    message.message += "Data: ";
    message.message += email_ESP8266.dataa;
    message.message += "\r\n";
    message.message += "Hora: ";
    message.message += email_ESP8266.hora;
    message.message += "\r\n";
    message.message += "Peso: ";
    message.message += email_ESP8266.peso;
    message.message += " kg";
    message.message += "\r\n";
    message.message += "Peso Acumulado: ";
    message.message += email_ESP8266.acumulado;
    message.message += " kg";
    message.message += "\r\n";   
    message.message += "\r\n";
    message.message += "LOCALIZAÇÃO:\r\n";
    message.message += "Longitude: ";
    message.message += email_ESP8266.longitude;
    message.message += "\r\n";
    message.message += "Latitude: ";
    message.message += email_ESP8266.latitude;
    message.message += "\r\n";
    message.message += "Altitude: ";
    message.message += email_ESP8266.altitude;
    message.message += "\r\n";
    

    EMailSender::Response resp = emailSend.send(email_ESP8266.emailTo1, message);

    Serial.println("Sending status: ");

    Serial.println(resp.status);
    Serial.println(resp.code);
    Serial.println(resp.desc);
    if(strlen(email_ESP8266.emailTo2)>0)
    {
       EMailSender::Response resp = emailSend.send(email_ESP8266.emailTo2, message);

      Serial.println("Sending status: ");

      Serial.println(resp.status);
      Serial.println(resp.code);
      Serial.println(resp.desc);
    }

    /*Serial.println("USER:");
    Serial.println(email_ESP8266.user);
    Serial.println("SENHA:");
    Serial.println(email_ESP8266.senha);
    Serial.println("SERVER:");
    Serial.println(email_ESP8266.server);
    Serial.println("PORTA");
    Serial.println(email_ESP8266.porta);
    Serial.println("EMAILTO:");
    Serial.println(email_ESP8266.emailTo1);
    Serial.println("TEXTO1:");
    Serial.println(email_ESP8266.texto1);
    Serial.println("TEXTO2:");
    Serial.println(email_ESP8266.texto2);
    Serial.println("DATA:");
    Serial.println(email_ESP8266.dataa);
    Serial.println("HORA:");
    Serial.println(email_ESP8266.hora);
    Serial.println("PESO:");
    Serial.println(email_ESP8266.peso);
    Serial.println("ACUMULADO:");
    Serial.println(email_ESP8266.acumulado);*/
}



#endif // DEFINES_H
