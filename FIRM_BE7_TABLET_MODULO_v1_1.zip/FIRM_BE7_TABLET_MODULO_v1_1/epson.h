#ifndef EPSON_H
#define EPSON_H

#include <string.h>                   /* LPC23xx definitions                */
#include <stdio.h>
#include <math.h>
#include "mprintf.h"
extern char f_buf[100];
extern estrutura5 etiqueta_ESP8266;

void print_epson(void)
{  
  int i = 0;
  for (i = 0; i < etiqueta_ESP8266.copias; i++)
  {
    Serial.write(0x1b); Serial.write(0x40); // inicializa
    Serial.write(0x1b); Serial.write(0x61); Serial.write(1); // cetralizar
    Serial.write(0x1b); Serial.write(0x33); Serial.write(50); //espacamento de linhas
    Serial.write(0x1d); Serial.write(0x21); Serial.write(0x1); // seleciona fonte dobro 1
    Serial.print("----------------------------------------\n");
    Serial.write(0x1d); Serial.write(0x21); Serial.write(0x11); // seleciona fonte maior dobro na horizontal e vertical

    if((etiqueta_ESP8266.comando & 0x01)==0x01)
    {
      Serial.write(etiqueta_ESP8266.texto1);
      Serial.write("\n");
    }
    if((etiqueta_ESP8266.comando & 0x02)==0x02)
    {
      Serial.write(etiqueta_ESP8266.texto2);
      Serial.write("\n");
    }

    if((etiqueta_ESP8266.comando & 0x03)!=0x0)
    {
      Serial.write(0x1d); Serial.write(0x21); Serial.write(0x1); // seleciona fonte dobro 1
      Serial.print("----------------------------------------\n");
    }

    Serial.write(0x1b); Serial.write(0x61); Serial.write(0); // left
    // Serial.write(0x1d);Serial.write(0x21);Serial.write(0x11);// seleciona fonte dobro 1
    
    if((etiqueta_ESP8266.comando & 0x04)==0x04)
    {
      Serial.write("Cliente: ");
      Serial.write(etiqueta_ESP8266.cliente);
      Serial.write("\n");
    }

    if((etiqueta_ESP8266.comando & 0x08)==0x08)
    {
      Serial.write("Produto: ");
      Serial.write(etiqueta_ESP8266.produto);
      Serial.write("\n");
    }
    

    if(etiqueta_ESP8266.tipo==4)
    {
      Serial.write("Peso Liquido: ");
      Serial.write(etiqueta_ESP8266.peso);
      Serial.write(" kg");
      Serial.write("\n");

      Serial.write("Peso Bruto: ");
      Serial.write(etiqueta_ESP8266.peso_bruto);
      Serial.write(" kg");
      Serial.write("\n");

      Serial.write("Tara: ");
      Serial.write(etiqueta_ESP8266.tara);
      Serial.write(" kg");
      Serial.write("\n");
    }
    else
    {
      Serial.write("Peso: ");
      Serial.write(etiqueta_ESP8266.peso);
      Serial.write(" kg");
      Serial.write("\n");
    }

    if((etiqueta_ESP8266.comando & 0x10)==0x10)
    {
      Serial.write("Acum.: ");
      Serial.write(etiqueta_ESP8266.acumulado);
      Serial.write(" kg");
      Serial.write("\n");
    }

    if((etiqueta_ESP8266.comando & 0x20)==0x20)
    {
      Serial.write("Data: ");
      Serial.write(etiqueta_ESP8266.dataa);
      Serial.write("\n");
    }

    if((etiqueta_ESP8266.comando & 0x40)==0x40)
    {
      Serial.write("Hora: ");
      Serial.write(etiqueta_ESP8266.hora);
      Serial.write("\n");
    }

    Serial.write(0x1d); Serial.write(0x21); Serial.write(0x1); // seleciona fonte dobro 1

    Serial.print("----------------------------------------\n");
    Serial.write(0x1b); Serial.write(0x64); Serial.write(2); //imprime e avança n linhas

    Serial.write(0x1d); Serial.write(0x56); Serial.write(66); Serial.write(0); //corta o papel
  }

}

#endif // DEFINES_H
