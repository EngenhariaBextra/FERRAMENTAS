#ifndef GITHUB_H
#define GITHUB_H

// A single, global CertStore which can be used by all
// connections.  Needs to stay live the entire time any of
// the WiFiClientBearSSLs are present.

#include <CertStoreBearSSL.h>
BearSSL::CertStore certStore;
#include <ESP_OTA_GitHub.h>

/* Set up values for your repository and binary names */
#define GHOTA_USER "EngenhariaBextra"
#define GHOTA_REPO "BE7_TABLET"
#define GHOTA_CURRENT_TAG "1.3"
#define GHOTA_BIN_FILE "FIRM_BE7_TABLET_MODULO.bin"
#define GHOTA_ACCEPT_PRERELEASE 0



void handle_upgade() {
  // Initialise Update Code
  //We do this locally so that the memory used is freed when the function exists.
  ESPOTAGitHub ESPOTAGitHub(&certStore, GHOTA_USER, GHOTA_REPO, GHOTA_CURRENT_TAG, GHOTA_BIN_FILE, GHOTA_ACCEPT_PRERELEASE);
  
  Serial.println("Checking for update...");
    if (ESPOTAGitHub.checkUpgrade()) {
    Serial.print("Upgrade found at: ");
    Serial.println(ESPOTAGitHub.getUpgradeURL());
    if (ESPOTAGitHub.doUpgrade()) {
      Serial.println("Upgrade complete."); //This should never be seen as the device should restart on successful upgrade.
      ESP.restart();
    } else {
      Serial.print("Unable to upgrade: ");
      Serial.println(ESPOTAGitHub.getLastError());
    }
    } else {
    Serial.print("Not proceeding to upgrade: ");
    Serial.println(ESPOTAGitHub.getLastError());
    }
}

#endif // DEFINES_H
