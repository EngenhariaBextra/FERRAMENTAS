#ifndef WIFIMANAGER_H
#define WIFIMANAGER

#include <WiFiManager.h> // https://github.com/tzapu/WiFiManager
#include <Arduino.h>
#include <EEPROM.h>
#include "defines.h"

#define timeoutW 1000 // seconds to run for
WiFiManager wm;

class IPAddressParameter : public WiFiManagerParameter {
  public:
    IPAddressParameter(const char *id, const char *placeholder, IPAddress address)
      : WiFiManagerParameter("") {
      init(id, placeholder, address.toString().c_str(), 16, "", WFM_LABEL_BEFORE);
    }

    bool getValue(IPAddress &ip) {
      return ip.fromString(WiFiManagerParameter::getValue());
    }
};

void wifi_manager(void)
{
  char flag=0;
  ip = sett.ip;
  gateway = sett.gtw;
  subnet = sett.mask;
  IPAddressParameter param_ip("ip", "ENDERE&CcedilO IP:", ip);
  IPAddressParameter param_gtw("gateway", "GATEWAY IP:", gateway);
  IPAddressParameter param_mask("subnet", "SUB REDE:", subnet);

  wm.addParameter( &param_ip );
  wm.addParameter( &param_gtw );
  wm.addParameter( &param_mask );

  //SSID & password parameters already included
  
  if (!wm.startConfigPortal("BE7_WifiManager")) {
    Serial.println("failed to connect and hit timeout");
    delay(3000);
    ESP.restart();
    //reset and try again, or maybe put it to deep sleep        
  }

  if (param_ip.getValue(ip)) {
    sett.ip = ip;

    Serial.print("IP: ");
    Serial.println(ip);
  } else {
    Serial.println("Incorrect IP");
  }

  if (param_gtw.getValue(gateway)) {
    sett.gtw = gateway;

    Serial.print("gateway: ");
    Serial.println(gateway);
  } else {
    Serial.println("Incorrect IP");
  }

  if (param_mask.getValue(subnet)) {
    sett.mask = subnet;

    Serial.print("subnet: ");
    Serial.println(subnet);
  } else {
    Serial.println("Incorrect IP");
  }

  EEPROM.put(0, sett);
  if (EEPROM.commit()) {
    Serial.println("Settings saved");        
  } else {
    Serial.println("EEPROM error");
  }

  
}

void wifi_manager2(void)
{
  //set static ip
  //wm.setSTAStaticIPConfig(IPAddress(192,168,43,2), IPAddress(192,168,43,1), IPAddress(255,255,255,0)); // set static ip,gw,sn

  // wm.setShowStaticFields(true); // force show static ip fields
  // wm.setShowDnsFields(true);    // force show dns field always

  // set configportal timeout
  wm.setConfigPortalTimeout(timeoutW);

  if (!wm.startConfigPortal("BEXTRA_BE7")) {
    Serial.println("failed to connect and hit timeout");
    delay(3000);
    //reset and try again, or maybe put it to deep sleep
    ESP.restart();
    delay(5000);
  }

  //if you get here you have connected to the WiFi
  Serial.println("connected...yeey :)");

}

void reset_wifi_manager(void)
{
  wm.resetSettings();
}

#endif // DEFINES_H
