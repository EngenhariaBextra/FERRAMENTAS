#ifndef ZEBRA_H
#define ZEBRA_H

#include <string.h>                   /* LPC23xx definitions                */
#include <stdio.h>
#include <math.h>
#include "mprintf.h"
extern char f_buf[100];
extern estrutura5 etiqueta_ESP8266;

void print_zebra(void)
{
  int i = 0;
  for (i = 0; i < etiqueta_ESP8266.copias; i++)
  {
    Serial.print("^XA");

    Serial.print("^LL700");

    Serial.print("^LH0,0");

    Serial.print("^DFR:SAMPLE.GRF^FS");

    Serial.print("^FO100,100^GB600,0,4^FS");

    if ((etiqueta_ESP8266.comando & 0x01) == 0x01)
    {
      Serial.print("^FO120,140^ADN,36,20^FD");
      Serial.print(etiqueta_ESP8266.texto1);
      Serial.print("^FS");
    }

    if ((etiqueta_ESP8266.comando & 0x02) == 0x02)
    {
      Serial.print("^FO120,190^ADN,36,20^FD");
      Serial.print(etiqueta_ESP8266.texto2);
      Serial.print("^FS");
    }

    if ((etiqueta_ESP8266.comando & 0x03) != 0x0)
      Serial.print("^FO100,240^GB600,0,4^FS");

    if ((etiqueta_ESP8266.comando & 0x04) == 0x04)
    {
      Serial.print("^FO120,290^ADN,36,20^FDCLIENTE: ");
      Serial.print(etiqueta_ESP8266.cliente);
      Serial.print("^FS");
    }

    if ((etiqueta_ESP8266.comando & 0x08) == 0x08)
    {
      Serial.print("^FO120,340^ADN,36,20^FDPRODUTO: ");
      Serial.print(etiqueta_ESP8266.produto);
      Serial.print("^FS");
    }

    if (etiqueta_ESP8266.tipo == 4)
    {
      Serial.print("^FO120,390^ADN,36,20^FDPESO: ");
      Serial.print(etiqueta_ESP8266.peso);
      Serial.print(" kg");
      Serial.print("^FS");

      Serial.print("^FO120,440^ADN,36,20^FDPESO BRUTO: ");
      Serial.print(etiqueta_ESP8266.peso_bruto);
      Serial.print(" kg");
      Serial.print("^FS");

      Serial.print("^FO120,490^ADN,36,20^FDTARA: ");
      Serial.print(etiqueta_ESP8266.tara);
      Serial.print(" kg");
      Serial.print("^FS");

      if ((etiqueta_ESP8266.comando & 0x10) == 0x10)
      {
        Serial.print("^FO120,540^ADN,36,20^FDACUM.: ");
        Serial.print(etiqueta_ESP8266.acumulado);
        Serial.print(" kg");
        Serial.print("^FS");
      }

      if ((etiqueta_ESP8266.comando & 0x20) == 0x20)
      {
        Serial.print("^FO120,590^ADN,36,20^FDDATA: ");
        Serial.print(etiqueta_ESP8266.dataa);
        Serial.print("^FS");
      }

      if ((etiqueta_ESP8266.comando & 0x40) == 0x40)
      {
        Serial.print("^FO120,640^ADN,36,20^FDHORA: ");
        Serial.print(etiqueta_ESP8266.hora);
        Serial.print("^FS");
      }
    }
    else
    {

      Serial.print("^FO120,390^ADN,36,20^FDPESO: ");
      Serial.print(etiqueta_ESP8266.peso);
      Serial.print(" kg");
      Serial.print("^FS");

      if ((etiqueta_ESP8266.comando & 0x10) == 0x10)
      {
        Serial.print("^FO120,440^ADN,36,20^FDACUM.: ");
        Serial.print(etiqueta_ESP8266.acumulado);
        Serial.print(" kg");
        Serial.print("^FS");
      }

      if ((etiqueta_ESP8266.comando & 0x20) == 0x20)
      {
        Serial.print("^FO120,490^ADN,36,20^FDDATA: ");
        Serial.print(etiqueta_ESP8266.dataa);
        Serial.print("^FS");
      }

      if ((etiqueta_ESP8266.comando & 0x40) == 0x40)
      {
        Serial.print("^FO120,540^ADN,36,20^FDHORA: ");
        Serial.print(etiqueta_ESP8266.hora);
        Serial.print("^FS");
      }
    }

    if(etiqueta_ESP8266.tipo == 4)
      Serial.print("^FO100,700^GB600,0,4^FS");
    else
      Serial.print("^FO100,600^GB600,0,4^FS");

    Serial.print("^XZ");

    Serial.print("^XA");

    Serial.print("^XFR:SAMPLE.GRF");

    Serial.print("^XZ");
  }

}

#endif // DEFINES_H
