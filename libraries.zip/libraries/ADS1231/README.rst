###############
ADS1231 library
###############

:author: aerowind
:date: Jan 31, 2014

From `ADS1231_beta.zip`_ via `Topic "SPI Load cell chip ADS1231"`_.

.. _ADS1231_beta.zip: http://forum.arduino.cc/index.php?action=dlattach;topic=131086.0;attach=67564
.. _Topic "SPI Load cell chip ADS1231": http://forum.arduino.cc/index.php?topic=131086.msg1570340#msg1570340
