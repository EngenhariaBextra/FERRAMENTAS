This is just one of many different tools I've built. Most of these are just dependent on the CoogleIOT framework for basics
and implement other specific functions. As I build other things I will post links to those repositories here:

https://github.com/ThisSmartHouse/coogle-switch - Smart Switch / Relay Control
